<template>
  <div class="card-body">I'm Superman.</div>
</template>

<script>
export default {
  mounted() {
    console.log("Component mounted.");
  },
};
</script>
