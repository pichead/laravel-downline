<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('others/styles/Datatable.css')); ?>">




<style>

  .dataTables_length{
    display: none;
  }
  .dataTables_filter{
    display: none;
  }

</style>

<?php $__env->startSection('content'); ?>
<br>

<div class="container  mb-5">
        <div class="col-10 mx-auto">
            <div class="mx-auto col-12 p-0">
                <?php echo $__env->make('inc.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            <div class="form-row mx-0 my-auto">

                <div class="col-7 col-sm-8 col-lg-10 h3 my-auto">ตระกร้าสินค้า</div>
                <div class="col-5 col-sm-4 col-lg-2 px-0 clearfix">
                  <button id="btn-update-cart" class="btn col float-right px-auto blue-btn" type="button">อัพเดทตระกร้า</button>
                </div>
              </div>
            <form method="POST" action="<?php echo e(asset('CreateBill')); ?>"  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if($item == '[]'): ?>
                    <div class="row mx-auto p-4 mt-5" style="background-color:#eaeaea">
                        <div class="col-12  text-center">ไม่มีข้อมูลสินค้า กรุณาสั่งซื้อสินค้าก่อน</div>
                        <a class="btn mx-auto px-4 mt-4" href="<?php echo e(asset('stock')); ?>" type="button" style="background-color: #D7B0EF; color:white;">รายการสินค้า</a>
                    </div>
                <?php else: ?>
                <div class="tb-search-wrapper mt-4">
                    <table id="tb-stocks" class="re-table table-mobile table-stocks mt-2 mb-4">
                        <col width="auto">
                        <col width="auto">
                        <col width="auto">
                        <col width="150px">
                        <col width="150px">
                        <col width="200px">
                      <thead>
                            <tr>
                                <th class="text-lg-center" scope="col">No.</th>
                                <th class="text-lg-center" scope="col">รายการสินค้า </th>
                                <th class="text-lg-right px-lg-0" scope="col">ราคาต่อชิ้น</th>
                                <th class="text-lg-right px-lg-0" scope="col">จำนวน</th>
                                <th class="text-lg-right px-lg-0" scope="col">ราคารวม</th>
                                <th class="text-lg-center" scope="col"></th>
                            </tr>
                        </thead>
                
                        <tbody>
                            <?php
                                $count = 0;
                            ?>
                          <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php 
                                $stockname = App\Models\Stock::where('id',$item_row->stock_id)->first();
                            ?>
                            <?php $__currentLoopData = $price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item_row->amount >= $price_row->start_total && $item_row->amount <= $price_row->end_total && $price_row->stock_id == $item_row->stock_id): ?>
                                    <?php
                                        $amount = $item_row->amount;
                                        $priceperunit = $price_row->price;
                                        $total = $amount * $priceperunit;
                                        $count = $count+1;
                                    ?>
                                    <tr class="cart-rows" data-cartid="<?php echo e($item_row->id); ?>" data-amountid="price-<?php echo e($count); ?>">
                                        <td class="text-xl-center px-0">
                                            <div class="pl-2"><?php echo e($count); ?></div>
                                            <input class="d-none" name="itemid[]" value="<?php echo e($item_row->id); ?>" >
                                        </td>
                                        <td class="px-0" >
                                            <input class="d-none" name="stock_id[]" value="<?php echo e($stockname->id); ?>" >
                                            <div class="pl-2" ><span class="stock-extra-unit"><?php echo e($count); ?>. </span><?php echo e($stockname->name); ?></div>
                                        </td>
                                        <td class="text-xl-right px-0" >
                                            <input class="d-none" id="input-price-unit-<?php echo e($count); ?>" name="priceperunit[]" value="<?php echo e(number_format($priceperunit,2)); ?>">
                                            
                                            <span id="priceunit-<?php echo e($count); ?>"><?php echo e(number_format($priceperunit,2)); ?></span>
                                        </td>
                                        <td class="text-xl-right px-0">
                                            
                                                <span class="stock-extra-unit">จำนวน : </span>
                                                <input name="amount[]" value="<?php echo e($item_row->amount); ?>" type="number" min="1" id="price-<?php echo e($count); ?>" 
                                                data-inputpriceunit="input-price-unit-<?php echo e($count); ?>" 
                                                data-priceunit="priceunit-<?php echo e($count); ?>" 
                                                data-resultid="result-<?php echo e($count); ?>"
                                                data-totalresultid="totalresult-<?php echo e($count); ?>"
                                                data-stockid="<?php echo e($stockname->id); ?>"
                                                class="price-identifier text-center" style="width: 120px">
                                        
                                        </td>
                                        
                                        <td class="text-xl-right px-0">
                                                <span id="totalresult-<?php echo e($count); ?>" class="d-none price item" ><?php echo e($total); ?></span>
                                                <span id="result-<?php echo e($count); ?>" name="total[]" ><?php echo e(number_format($total,2)); ?></span>                                            
                                        </td>

                                        <td class="text-xl-right">
                                            <button class="btn col-5 ml-1 green-btn btn-sm" type="button" data-toggle="modal" data-target="#<?php echo e($item_row->id); ?>" >เรทราคา</button>
                                            <button class="btn col-5 ml-1 red-btn btn-sm" type="button" data-toggle="modal" data-target="#del-item-modal-<?php echo e($item_row->id); ?>"  name="stock_id" value="" >ลบ</button>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                            
                            
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td colspan="4"></td>
                            <td colspan="2" class="text-xl-right" id="cash-out" ></td>
                        </tr>
                        </tbody>

                    </table>
                  </div>

                    <br>
                    <div class="row">
                        <div class="mx-auto">
                            <button class="btn px-4 purple-btn" name="create" type="submit" >สั่งซื้อ</button>
                        </div>
                    </div>
                <?php endif; ?>
            </form>

            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                        $stockname = App\Models\Stock::where('id',$item_row->stock_id)->first();
                    ?>
                    <div class="modal fade" id="<?php echo e($item_row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <?php
                                    $name = App\Models\Stock::where('id',$item_row->stock_id)->first();                   
                                ?>
                                    <h5 class="modal-title" id="exampleModalLabel">เรทราคา <?php echo e($name->name); ?></h5>
                                
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            </div>
                            <div class="modal-body">
                                
                                <table class="col-12 re-table table-mobile table-stocks mt-2 mb-4 dataTable">
                                    <thead>
                                        <tr class="row m-0">
                                            <th class="col col-xl text-lg-center sorting_disabled">จำนวน</th>
                                            <th class="col col-xl text-lg-center sorting_disabled">ราคา/หน่วย</th>
                                        </tr>
                                    </thead>
                                    <tbody id="tbody">
                                        <?php $__currentLoopData = $price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($price_row->stock_id == $item_row->stock_id): ?>
                                            <tr id="tr_0" role="row" class="row m-0 mb-5 mb-xl-0">   
                                                <td class="col col-xl text-lg-center">
                                                    <div class="row ">
                                                        <div class="col-3 mx-auto"><?php echo e($price_row->start_total); ?></div>
                                                        -
                                                        <div class="col-3 mx-auto"><?php echo e($price_row->end_total); ?></div>
                                                    </div>
                                                </td>
                                                <td class="col col-xl text-center">
                                                    <div class="col-4 mx-auto"><?php echo e($price_row->price); ?></div>
                                                </td>

                                            </tr>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button>
                            </div>
                        </div>
                        </div>
                    </div>

                    <div class="modal" id="del-item-modal-<?php echo e($item_row->id); ?>">
                        <div class="modal-dialog">
                          <div class="modal-content">
                            <form method="DELETE" action="<?php echo e(asset('DelItem'.'/'.$item_row->id)); ?>"  enctype="multipart/form-data">
                                 <?php echo csrf_field(); ?>
                                <div class="modal-header">
                                <h5 class="modal-title">ลบสินค้า : <?php echo e($stockname->name); ?></h5>
                                <button class="close" data-dismiss="modal">×</button>
                                </div>
                                <div class="modal-body">
                                <div class="h5">คุณต้องการลบ "<?php echo e($stockname->name); ?>" ออกจากตระกร้าหรือไม่?</div>
                                <div>หากต้องการลบ กดที่ปุ่ม "ลบ" เมื่อทำการลบแล้วจะไม่สามารถแก้ไขข้อมูลได้</div>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn red-btn col-3">ลบ</button>
                                <button class="btn blue-btn col-3" data-dismiss="modal">ปิด</button>
                                </div>
                            </form>
                          </div>
                        </div>
                      </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

</div>

<?php $__env->stopSection(); ?>






<?php $__env->startSection('script'); ?>

<script>
    
$('#btn-update-cart').click( ( e ) => {
     e.preventDefault();

     var rowitemid = [];
        $('input[name="itemid[]"]').each( function() {
            rowitemid.push(this.value);
        });

    var rowamount = [];
        $('input[name="amount[]"]').each( function() {
            rowamount.push(this.value);
        });
    
    $.ajax({
        url: 'api/cart/updateCart',
        type: 'post',
        data: {"_token": "<?php echo e(csrf_token()); ?>",rowitemid:rowitemid,rowamount:rowamount},
        success:function(response){

            $('#json-success-message').text('successfully update cart');
            $('#user-success-msg').removeClass('d-none');
            $('#user-success-msg').addClass('show');

            setTimeout(()=>{
                $('#user-success-msg').removeClass('show');
                $('#user-success-msg').addClass('d-none');
            },3000);
            
        },
        error: function( error ){
            $('#json-faild-message').text('successfully update cart');
            $('#user-faild-msg').removeClass('d-none');
            $('#user-faild-msg').addClass('show');

            setTimeout(()=>{
                $('#user-faild-modal').removeClass('show');
                $('#user-faild-msg').addClass('d-none');
            },3000);
        }
    });

});



let prices = null;
// let cart = null;
$(document).ready(()=>{

    loadPrice();

});

function loadPrice(){

    $.get( "api/price/loadPrice",function(response){

            prices = JSON.parse(response.prices);

    }).fail(function(error){
                console.log('api/loadprice',error);
    });


}

    var sum = 0;
    $('.price').each(function(){
        sum += parseFloat($(this).text());
    });
    $('#cash-out').html("ราคารวมทั้งหมด "+(numeral(sum).format('0,0.00'))+" บาท");





$('.price-identifier').on('keyup change', (e) =>{

        console.log(e);
        var selected_stock_id = $('#' + e.target.id).data('stockid');
        var qty = isNaN(e.target.value) ? 0 : e.target.value;
        console.log(selected_stock_id,qty);

        let price = getPrice(selected_stock_id,qty);
        let total_price = price * qty;
        
        var resultid = $('#' + e.target.id).data('resultid');
        var totalresultid = $('#' + e.target.id).data('totalresultid');
        console.log(totalresultid);

        // .format('0,0')
        $('#' + resultid).html(numeral(total_price).format('0,0.00'));
        $('#' + totalresultid).html(total_price);
        // priceunit
        var priceunitid = $('#' + e.target.id).data('priceunit');
        $('#' + priceunitid).html(numeral(price).format('0,0.00'));
    
        var items = $('.item'),
            cashOut = $('#cash-out'),
            sum = 0;
        $.each(items, function(value) {
        // items[value] will contain an HTML element, representing an 'item'.
        var itemValue = parseFloat(items[value].innerHTML);
        console.log(itemValue)
        sum += !isNaN(itemValue) ? itemValue : 0;
        });

        cashOut.html('ราคารวมทั้งหมด ' + numeral(sum).format('0,0.00') +' บาท');

});


function getPrice(selected_stock_id,qty){


    for(var i=0; i < prices.length; i++){

        var selected_price = prices[i];
        if(selected_price.stock_id == selected_stock_id && selected_price.start_total <= qty && selected_price.end_total >= qty ){
                    // console.log('the price is ', selected_price.price );
                    return selected_price.price;
        }

        }

    return 0;
    
}


</script>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cp572785/public_html/v-dealers.com/app_v/resources/views/payment/cart.blade.php ENDPATH**/ ?>