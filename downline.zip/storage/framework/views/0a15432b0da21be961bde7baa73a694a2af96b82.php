

<?php $__env->startSection('content'); ?>
<br>
<div class="container mb-5">
    <div class="row clearfix">
        <h3 class="mx-auto">ชำระเงิน</h3>
    </div>
    <br>
    <form method="POST" class="was-validated" action="<?php echo e(asset('PaymentUpdate').'/'.$Payment->id); ?>"  enctype="multipart/form-data">
        <?php echo e(method_field('PUT')); ?>

        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-11 col-md-8  border border-dark mx-auto p-5 rounded" style="background-color: white;">
                <div class="mx-2">
                    <div class="form-group">
                        <label>เลขที่สั่งซื้อสินค้า</label>
                        <input class="form-control"  value="<?php echo e(number_format($Payment->purchase_no,0,",","-")); ?>" readonly>
                    </div>

                    <table id="tb-stocks" class="col-12 table-mobile table-stocks mt-2 mb-4">
                        <thead>
                            <tr class="row m-0 table-success py-1">
                                <td class="col-12 col-xl-1  text-lg-center sorting_disabled" >No.</td>
                                <td class="col-12 col-xl text-lg-center sorting_disabled" >รายการสินค้า</td>
                                <td class="col-12 col-xl text-lg-center sorting_disabled" >จำนวน</td>
                                <td class="col-12 col-xl text-lg-center sorting_disabled">ราคา</td>
                            </tr>
                        </thead>
                
                        <tbody>
                          <?php $__currentLoopData = $Order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Order_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $name = App\Models\Stock::where('id',$Order_row->stock_id)->first();                   
                            ?>
                            <tr role="row" class="row m-0 py-1">
                              <td class="col-12 col-xl-1 text-lg-center"><?php echo e($loop->index+1); ?></td>
                              <td class="col-12 col-xl ">
                                  <span class="stock-extra-unit"><?php echo e($loop->index+1); ?>. </span><?php echo e($name->name); ?>

                              </td>
                              <td class="col-12 col-xl text-lg-right"><?php echo e(number_format($Order_row->amount,0)); ?></td>
                              
                                <?php $__currentLoopData = $priceitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($Order_row->amount >= $price_row->start_total && $Order_row->amount <= $price_row->end_total && $price_row->stock_id == $Order_row->stock_id): ?>
                                        <?php
                                            $amount = $Order_row->amount;
                                            $priceperunit = $price_row->price;
                                            $total = $amount * $priceperunit;
                                        ?>
                                        <td class="col-12 col-xl text-lg-right"><?php echo e(number_format($total,2)); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <td class="col-12 mt-2 text-right font-weight-bold">ยอดสั่งซื้อ(บาท) <?php echo e(number_format($Price,2)); ?></td>
                        </tfoot>
                
                      </table>




                    <div class="form-group">
                        <label>ชื่อผู้ซื้อ</label>
                        <input class="form-control" type="fullname" value="<?php echo e($user->name); ?>" readonly/>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>เบอร์ติดต่อ</label>
                            <input type="tel" class="form-control" value="0<?php echo e($user->tel); ?>" readonly/>
                        </div>
                        <div class="form-group col-md-6">
                            <label>E-mail</label>
                            <input type="email" class="form-control" value="<?php echo e($user->email); ?>" readonly/>
                        </div>
                    </div>
                <?php if(isset($Payment->user_bank_id)): ?>
                    <?php
                        $bankname = App\Models\UserBank::where('id',$Payment->user_bank_id)->first();
                        $bank = App\Models\Bank::where('id',$bankname->bank_id)->first();
                    ?>
                    <div class="form-group">
                        <label>ธนาคาร</label>
                        <input class="d-none" value="<?php echo e($Payment->user_bank_id); ?>" name="bank_id" />
                        <input type="text" class="form-control" value="<?php echo e($bank->name); ?> (<?php echo e($bankname->name); ?>)" readonly/>
                    </div>
                    <div class="form-group">
                        <label>เลขบัญชีธนาคาร</label>
                        <input readonly="readonly" value="<?php echo e($bankname->account_no); ?>" class="form-control" required/>
                    </div>
                <?php else: ?>
                    <div class="form-group">
                        <label>ธนาคาร</label>
                        <select id="bank" class="form-control" name="bank_id" required> 
                            <option hidden disabled selected value>เลือกธนาคาร</option>
                            <?php $__currentLoopData = $toplinebank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Bank_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $bankname = App\Models\Bank::where('id',$Bank_row->bank_id)->first('name');
                                ?>
                                <option value="<?php echo e($Bank_row->id); ?>" data-no="<?php echo e($Bank_row->account_no); ?>"><?php echo e($bankname->name); ?> (<?php echo e($Bank_row->name); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        
                        <label>เลขบัญชีธนาคาร</label>
                        <input readonly id="no" class="form-control" type="number" required/>
                    </div>
                <?php endif; ?>


                    <div class="form-row">

                        <?php if(isset($Payment->pay_date)): ?>
                        <div class="form-group col-md-6">
                            <label>วันที่ชำระเงิน</label>
                            <input name="pay_date"  class="form-control" value="<?php echo e(DateTime::createFromFormat('Y-m-d H:i:s', $Payment->pay_date)->format('d/m/Y ')); ?>" readonly/>
                        </div>
                        <?php else: ?>
                        <div class="form-group col-md-6">
                            <label>วันที่ชำระเงิน</label>
                            <input type="date" name="pay_date" class="form-control" required/>
                        </div>
                        <?php endif; ?>

                        <?php if(isset($Payment->pay_time)): ?>
                        <div class="form-group col-md-6">
                            <label>เวลา</label>
                            <input name="pay_time" class="form-control" value="<?php echo e(DateTime::createFromFormat('Y-m-d H:i:s', $Payment->pay_time)->format('H:i:s ')); ?>" readonly/>
                        </div>
                        <?php else: ?>
                        <div class="form-group col-md-6">
                            <label>เวลา</label>
                            <input type="time" name="pay_time" class="form-control" required/>
                        </div>
                        <?php endif; ?>

                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label>ยอดสั่งซื้อ</label>
                            <input class="form-control" value="<?php echo e(number_format($Price,2)); ?>" readonly/>
                        </div>
                        <?php if(isset($Payment->pay_price)): ?>
                        <div class="form-group col-md-6">
                            <label>ยอดโอน</label>
                            <input class="d-none" name="pay_price" value="<?php echo e($Payment->pay_price); ?>">
                            <input class="form-control" value="<?php echo e(number_format($Payment->pay_price,2)); ?>" readonly/>
                        </div>
                        <?php else: ?>
                        <div class="form-group col-md-6">
                            <label>ยอดโอน</label>
                            <input class="form-control" name="pay_price" type="number" placeholder="ระบุจำนวนเงินที่โอนเข้ามา" required/>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php
                        $files = App\Models\PurchaseOrderImage::where('purchase_order_id',$Payment->id)->get();
                        $filecheck = App\Models\PurchaseOrderImage::where('purchase_order_id',$Payment->id)->first(); 
                    ?>
                    <?php if(isset($filecheck->purchase_order_id)): ?>
                    <div class="form-group">
                        <label  for="file">แนบรูปภาพ</label>
                        <br>
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a target="_new" href="<?php echo e(asset('app_v/public/uploads').'/'.$file_row->name.'/'); ?>"><?php echo e($loop->index+1); ?>. <?php echo e($file_row->name); ?></a>
                        <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <br>
                        <input type="file" name="file[]" class="form-control-file" accept=".jpg,.gif,.png" multiple >
                    </div>
                    <?php else: ?>
                    <div class="form-group">
                        <label for="file">แนบรูปภาพ</label>
                        <input type="file" name="file[]" class="form-control-file" accept=".jpg,.gif,.png" multiple >
                    </div>
                    <?php endif; ?>
                    <div class="form-group">
                        <label for="message">เพิ่มเติม</label>
                        <textarea class="form-control" id="message" rows="3" name="buyer_comment"></textarea>
                    </div>
                    
                </div>
            </div>
        </div>

    
        <br>
        <br>
        <div class="row">
            <div class="mx-auto">
                <button class="btn px-4 purple-btn" type="submit">บันทึก</button>
                <button class="btn px-4 red-btn" type="button">ยกเลิก</button>
            </div>
        </div>
    </form>

    
</div>

<?php $__env->stopSection(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(function(){
    $("#bank").change(function(){
        var no=$("#bank option:selected").data("no");
        console.log(no);
        $("#no").val(no);
    })
})

// $(function(){
//     $("#addprice").click(function(){
//         $(".btnaddrow").before('<tr role="row" class="price row m-0 mb-5 mb-xl-0"><td class="col col-xl text-lg-center"><div class="row "><input class="col-3 mx-auto">-<input class="col-3 mx-auto"></div></td><td class="col col-xl text-lg-center"><input class="col-4"></td><td class="col-1 col-xl-1 text-lg-center"><div class="delrow">X</div></td></tr>');
//     })
// })
</script>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\downline\resources\views/payment/create.blade.php ENDPATH**/ ?>