<nav class="navbar fixed-top navbar-dark navbar-expand-sm" style="background-color:#666a77;">
    <div class="container px-0 mx-0 mx-lg-5 px-lg-5 col-12 pr-lg-5">
        <!-- <div class="col-12 col-md-8"> -->
            <img src="<?php echo e(URL::to('others/favicon/vdealer-logo-sq300.png')); ?>" width="65" height="65">
            <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-0 ml-sm-auto">
                
                <?php if(auth()->guard()->guest()): ?>
                
                
                <?php else: ?>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?>

                    </a>

                    <div class="dropdown-menu dropdown-menu-right col-1 col-md" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
                <?php endif; ?>
            </ul>



        </div>
        <!-- </div> -->
    </div>
</nav>
<br>
<br>
<br>
<br><?php /**PATH /home/cp572785/public_html/v-dealers.com/app_v/resources/views/inc/navbarlogin.blade.php ENDPATH**/ ?>