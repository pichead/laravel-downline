<?php $__env->startSection('content'); ?>
<br>
<div class="container col-11 col-md-8">
    <div class="row">
      <div class="col-md-4 h3 pl-0">รายการสินค้า</div>
      <div class="col-md-7 px-0 offset-md-1">
        <a class="btn col-3" href="<?php echo e(asset('userSignup')); ?>" type="button" style="background-color: #72CAFF;color:white">สร้างผู้ใช้งาน</a>
        <input class="float-right col-8 form-control" type="text" placeholder="Search">
      </div>
    </div>
    <br>

    <div class="row">

        
        <table class="col-12 re-table table-mobile table-stocks mt-2 mb-4 dataTable">
            <thead>
                <tr class="row m-0">
                    
                    <th class="col-12 col-xl-6 text-lg-center sorting_disabled" >ชื่อ-สกุล</th>
                    <th class="col-12 col-xl-6 text-lg-center sorting_disabled"></th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $UserTree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $User_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php
                        $childs = App\Models\User::where('id',$User_row->child_id)->get();                   
                    ?>
                    
                    
                    <?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr role="row" class="row m-0 mb-5 mb-xl-0">
                        
                        <td class="col-12 col-xl-6 text-lg-center"><?php echo e($child->name); ?></td>
                        <td class="col-12 col-xl-6 ">
                            <a class="btn col-3 mx-1" type="button" href="<?php echo e(asset('price').'/'.$child->id.'/create'); ?>" style="background-color:#58d6cc; color:White">เรทราคา</a>
                            <a class="btn col-3 mx-1" type="button" data-toggle="modal" data-target="" style="background-color:#58d6cc; color:White">รายการสั่งซื้อ</a>
                            <a class="btn col-3 mx-1" type="button"  style="background-color:#58d6cc; color:White" href="<?php echo e(asset('users').'/'.$child->id.'/edit'); ?>">แก้ไข</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
            </tbody>
        </table>

    </div>

</div>

<script>
    
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dl\mlm-laravel\resources\views/user/index.blade.php ENDPATH**/ ?>