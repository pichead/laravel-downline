

<?php $__env->startSection('content'); ?>
<div class="container mb-5 col-11 col-md-6">
    <div class="mx-auto col-12 p-0">
        <?php echo $__env->make('inc.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="row">
      <div class="col-12 h3">เรทราคาสินค้า : <span><?php echo e($user_id->name); ?> : <?php echo e($stock->name); ?> (<?php echo e(number_format($stock->received_price,2)); ?> บาท)</div>
    
    </div>
    <br>
    <div class="p-4 border rounded" style="background-color: white">
        <form method="POST" class="was-validated"  action="<?php echo e(asset('pricecreate')); ?>"  enctype="multipart/form-data">

            <?php echo csrf_field(); ?>
            
            <input class="d-none" name="user_id" value="<?php echo e($user_id->id); ?> " />
            <input class="d-none" name="stock_id" value="<?php echo e($stock->id); ?>" />
            
            <?php
                $priceitem = App\Models\Price::where('user_id',$user_id->id)->where('stock_id',$stock->id)->first();
            ?>
            <?php if(isset($priceitem->stock_id)): ?>
            <h5 class="" style="color:red;">*หากต้องการแก้ไขเรทราคา จะต้องกำหนดเรทราคาใหม่ทั้งหมดเพื่อแทนที่เรทราคาเก่า</h5>
            <h4>เรทราคาปัจจุบัน</h4>
            <table class="col-12 re-table table-mobile table-stocks mt-2 mb-4 dataTable">
                <thead>
                    <tr class="row m-0">
                        <th class="col col-xl text-lg-center sorting_disabled">จำนวน</th>
                        <th class="col col-xl text-lg-center sorting_disabled">ราคา/หน่วย</th>
                        <th class="col-1 col-xl-1"></th>
                    </tr>
                </thead>

                <tbody>
                    
                    <?php $__currentLoopData = $price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr role="row" class="price row m-0 mb-5 mb-xl-0">
                        <td class="d-none"><input name="oldprice_id[]" value="<?php echo e($price_row->id); ?>"/></td>
                        <td class="col col-xl text-lg-center">
                            <div class="row ">
                                <div class="col-3 mx-auto text-center"><?php echo e($price_row->start_total); ?></div>
                                -
                                <div class="col-3 mx-auto text-center"><?php echo e($price_row->end_total); ?></div>
                            </div>
                        </td>
                        <td class="col col-xl text-lg-center">
                            <div class="col-4 mx-auto text-center"><?php echo e($price_row->price); ?></div>
                        </td>
                        <td class="col-1 col-xl-1 text-lg-center">                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
            <?php endif; ?>
            <h4>เรทราคาใหม่</h4>
            
            <table class="col-12 re-table table-mobile table-stocks mt-2 mb-4 dataTable">
                <thead>
                    <tr class="row m-0">
                        <th class="col col-xl text-lg-center sorting_disabled">จำนวน</th>
                        <th class="col col-xl text-lg-center sorting_disabled">ราคา/หน่วย</th>
                        <th class="col-1 col-xl-1"></th>
                    </tr>
                </thead>

                <tbody id="tbody">
                    <tr id="tr_0" role="row" class="price row m-0 mb-5 mb-xl-0">   
                        <td class="col col-xl text-lg-center">
                            <div class="row ">
                                <input class="col-4 mx-auto form-control" name="start_total[]" required>
                                -
                                <input class="col-4 mx-auto form-control" name="end_total[]" required>
                            </div>
                        </td>
                        <td class="col col-xl text-lg-center">
                            <input name="price_row[]" class="col-5 mx-auto form-control" required>
                        </td>
                        <td class="col-1 col-xl-1 text-lg-center">
                            
                        </td>
                    </tr>

                </tbody>
                <tfoot>
                    <tr class="btnaddrow">
                        <td class="row">
                            <div id="addBtn" class="mx-auto col-2 btn green-btn">เพิ่ม</div>
                        </td>
                    </tr>
                </tfoot>
            </table>
            <div class="row mt-5">
                <div class="mx-auto">
                    <button id="sm-tbn" class="btn purple-btn" type="submit"  >สร้างเรทราคาใหม่</button>
                    <button class="btn px-4 red-btn" href="<?php echo e(asset('price').'/'.$user_id->id); ?>" type="button" >ยกเลิก</button>
                </div>
            </div>
        </form>
    </div>


 
 

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
$(function(){
    $("#selectproduct").change(function(){
        var price=$("#selectproduct option:selected").data("price");
        var unit=$("#selectproduct option:selected").data("unit");
        console.log(price,unit);
        $("#productprice").val(price);
        $("#productunit").val(unit);
    })
})

// $(function(){
//     $("#addprice").click(function(){
//         $(".btnaddrow").before('<tr role="row" class="price row m-0 mb-5 mb-xl-0"><td class="col col-xl text-lg-center"><div class="row "><input class="col-3 mx-auto">-<input class="col-3 mx-auto"></div></td><td class="col col-xl text-lg-center"><input class="col-4"></td><td class="col-1 col-xl-1 text-lg-center"><div class="delrow">X</div></td></tr>');
//     })
// })
</script>



<script> 
    $(document).ready(function () { 
  
      // Denotes total number of rows 
      var rowIdx = 0; 
  
      // jQuery button click event to add a row 
      $('#addBtn').on('click', function () { 
  
        // Adding a row inside the tbody. 
        $('#tbody').append(`<tr id="R${++rowIdx}"class="price row m-0 mb-5 mb-xl-0">   
                    <td class="col col-xl text-lg-center">
                        <div class="row ">
                            <input class="col-4 mx-auto form-control" name="start_total[]" required>
                            -
                            <input class="col-4 mx-auto form-control" name="end_total[]" required>
                        </div>
                    </td>
                    <td class="col col-xl text-lg-center">
                        <input name="price_row[]" class="col-5 mx-auto form-control" required>
                    </td>
                    <td class="col-1 col-xl-1 text-lg-center">
                        <div class=" remove"
                  type="button">X</div> 
                    </td>
                </tr>`); 
      }); 
  
      // jQuery button click event to remove a row. 
      $('#tbody').on('click', '.remove', function () { 
  
        // Getting all the rows next to the row 
        // containing the clicked button 
        var child = $(this).closest('tr').nextAll(); 
  
        // Iterating across all the rows  
        // obtained to change the index 
        child.each(function () { 
  
          // Getting <tr> id. 
          var id = $(this).attr('id'); 
  
          // Getting the <p> inside the .row-index class. 
          var idx = $(this).children('.row-index').children('p'); 
  
          // Gets the row number from <tr> id. 
          var dig = parseInt(id.substring(1)); 
  
          // Modifying row index. 
          idx.html(`Row ${dig - 1}`); 
  
          // Modifying row id. 
          $(this).attr('id', `R${dig - 1}`); 
        }); 
  
        // Removing the current row. 
        $(this).closest('tr').remove(); 
  
        // Decreasing total number of rows by 1. 
        rowIdx--; 
      }); 
    }); 
  </script> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\downline\resources\views/user/priceitem.blade.php ENDPATH**/ ?>