<nav class="navbar fixed-top navbar-dark navbar-expand-sm mb-3 py-3 px-1 px-xs-2 px-lg-5 text-md-center" style="background-color:#666a77;">
    <div class="container px-0 mx-0 mx-lg-5 px-lg-5 col-12 pr-lg-5">
        <!-- <div class="col-12 col-md-8"> -->
        <a class="navbar-brand navFont mr-0 ml-lg-5" href="<?php echo e(asset('home')); ?>">V Dealer</a>
        <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse mr-lg-5 pr-lg-5 col-12 m-0 px-0 col-lg-10" id="navbarNav">
            <ul class="navbar-nav ml-0 ml-sm-auto">
                
                <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                </li>
                
                <?php else: ?>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?>

                    </a>

                    <div class="dropdown-menu dropdown-menu-right col-1 col-md" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
                <?php endif; ?>
            </ul>



        </div>
        <!-- </div> -->
    </div>
</nav>
<br>
<br>
<br>
<br><?php /**PATH C:\xampp\htdocs\dl\mlm-laravel\resources\views/inc/navbarlogin.blade.php ENDPATH**/ ?>