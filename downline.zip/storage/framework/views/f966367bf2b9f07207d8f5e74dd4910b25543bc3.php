



<?php $__env->startSection('content'); ?>

<div class="col-6 mx-auto">
  <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($user_row->id); ?> <?php echo e($user_row->name); ?>

    <br>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\downline\resources\views/user/test.blade.php ENDPATH**/ ?>