<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="image/png" href="<?php echo e(asset('others/favicon/favicon.png')); ?>">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

  <title>V Dealer</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <script src="https://cdn.zingchart.com/zingchart.min.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Prompt&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB" crossorigin="anonymous">
  <link rel="stylesheet" href="<?php echo e(asset('styles/app.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('styles/btn.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('styles/responsive.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('styles/table.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('styles/tables.css')); ?>">
  
  
  <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
  <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
  <link href="<?php echo e(asset('others/orgchart/orgchart.css')); ?>" rel="stylesheet" type="text/css"/>
  
  


  <?php echo $__env->yieldContent('style'); ?>

  <!-- Font Awesome JS -->
  <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
  <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

  <style media="screen">
    .navFont {
      color: #f7f7f7 !important;
    }

    body {
      background-color: #f2f2f2;
      font-family: 'Prompt', sans-serif;

    }

    .border-bottom-white{
      border-bottom: white solid 5px;
    };
  </style>

</head>

<body>


  <?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->yieldContent('content'); ?>



  <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>

  
  

  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>

  
  <script src="//cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>

  <?php echo $__env->yieldContent('script'); ?>
</body>

</html><?php /**PATH /home/cp572785/public_html/v-dealers.com/app_v/resources/views/layouts/web.blade.php ENDPATH**/ ?>