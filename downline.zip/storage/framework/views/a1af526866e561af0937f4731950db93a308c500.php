

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('others/styles/Datatable.css')); ?>">




<style>

  .dataTables_length{
    display: none;
  }
  .dataTables_filter{
    display: none;
  }

</style>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-12 mb-5 col-md-9">
    <div class="mx-auto col-12 p-0">
      <?php echo $__env->make('inc.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
  <?php
  $myid = Auth::user()->id ;
  $bank = App\Models\UserBank::where('user_id',$myid)->first();
  ?>
  <?php if(isset($bank->id)): ?>
  <?php else: ?>
  <div id="user-error-msg" class="alert alert-danger alert-dismissible fade show">
    ท่านยังไม่ไม่ได้เพิ่มบัญชีธนาคาร กรุณาเพิ่มบัญชีธนาคารก่อน <a style="color: red" href="<?php echo e(asset('EditUser')); ?>">คลิกที่นี่</a> เพื่อเพิ่มธนาคาร
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
<?php endif; ?>  
  <div class="form-row mx-0 my-auto">
    <div class="col-12 my-auto px-0 h3">รายการสินค้า</div>

    <div class="col-12 mt-3 px-0">
      <input type="text" id="search-bar" class="form-control search-input" placeholder="Search..." />
    </div>

  </div>
  <div class="tb-search-wrapper mt-4">
    <table id="tb-stocks" class="re-table table-mobile table-stocks mt-2 mb-4">
      <thead>
            <tr>
                <th class="text-lg-center sorting_disabled" scope="col">No.</th>
                <th class="text-lg-center sorting_disabled" >รายการสินค้า </th>
                <th class="text-lg-right px-lg-0 sorting_disabled">จำนวนคงเหลือ</th>
                <th class="text-lg-center sorting_disabled">ราคา</th>
            </tr>
        </thead>

        <tbody>
          <?php $__currentLoopData = $Stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Stock_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
              <tr>
                
                    <td class="text-xl-center px-0">
                      <div class="pl-2"><?php echo e($loop->index+1); ?></div>
                    </td>
                    <td class="px-0">
                      <div class="pl-2"><span class="stock-extra-unit"><?php echo e($loop->index+1); ?>. </span><?php echo e($Stock_row->name); ?></div>
                    </td>
                    <td class="text-xl-right px-0">
                      <div class="pl-2"><span class="stock-extra-unit">จำนวนคงเหลือ : </span><?php echo e(number_format($Stock_row->amount,0)); ?></div>
                    </td>
                    <td class="text-center px-0"><div class="pl-2">
                        <?php
                          $priceitem = App\Models\Price::where('user_id',$myid)->where('stock_id',$Stock_row->id)->first();
                        ?>
                          
                        <?php if(isset($bank->id)): ?>
                          <?php if(isset($priceitem->stock_id)): ?>
                            <form method="POST" action="<?php echo e(asset('addtocart')); ?>"  enctype="multipart/form-data">
                              <?php echo csrf_field(); ?>
                              <button class="btn col-4 ml-1 green-btn btn-sm" name="stock_id" value="<?php echo e($Stock_row->id); ?>" type="submit" >สั่งซื้อ</button>
                            </form>
                          <?php else: ?>
                            <div class="text-center">ไม่กำหนด</div>
                          <?php endif; ?>
                        <?php else: ?>
                          <?php if(isset($priceitem->stock_id)): ?>
                              <button class="btn col-4 ml-1 btn-secondary btn-sm" name="stock_id" value="<?php echo e($Stock_row->id); ?>" type="submit" disabled>สั่งซื้อ</button>

                          <?php else: ?>
                            <div class="text-center">ไม่กำหนด</div>
                          <?php endif; ?>
                        <?php endif; ?>
                      </div>
                      </td>
                </form>
              </tr>
            
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
  </div>



    


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>



<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>


<script type="text/javascript">


  $(document).ready( function () {


  $('#modal-btn-yes').click(function(){
      deleteStock();
  });

  $('#tb-stocks').dataTable( {
      "ordering":false,
      "info":true,
      // "dom": '<"top"i>rt<"bottom"><"clear">'
  } );


  $('#search-bar').on( 'keyup click', function () {
        // table.search($('#mySearchText').val()).draw();
        $('#tb-stocks').dataTable().fnFilter(this.value);

  } );


} );

</script>


<script type="text/javascript">

  function confirmDelete(id){

    var name = $('#btn-delete-' + id).data('name');


    $('#modal-btn-yes').data('id',id);

    $('#modal-stock-name').html('"' + name + '"');

    $('#deleteModal').modal('show');
  }
  function deleteStock(){

        var id = $('#modal-btn-yes').data('id');
        var token = $("meta[name='csrf-token']").attr("content");

        console.log(id);


        $.ajax({
        type:     "delete",
        url:      "./api/stocks/"+id,
        data: {
              _token: token,
          },
        success:function(response){
          location.reload();
        },
        error: function (xhr, status, error) {
            console.log(xhr.responseText);
        }
        });


    }

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\downline\resources\views/stock/indexstore.blade.php ENDPATH**/ ?>