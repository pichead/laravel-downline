

<?php $__env->startSection('style'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
      
      


      <div class="container mb-5">
      <h1 class="text-center">มุมมองเครือข่าย</h1>
      

      <div class="row mt-5">
        <?php $__currentLoopData = $top; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tops): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php 
            $topname = App\Models\User::where('id',$tops->parent_id)->first();
            $child = App\Models\UserTree::where('parent_id',$topname->id)->get();
          ?>
          <div class="col-12 col-sm-6 col-lg-4  px-0 my-3">
            <div class="mx-auto card  h-100 px-0 col-11">
              <div class="card-header" style="background-color: #a3a8c1; color:white">
                ตัวแทน : <?php echo e($topname->name); ?>

              </div>
              <div class="card-body">
                <?php $__currentLoopData = $child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                    $childname = App\Models\User::where('id',$childs->child_id)->first();
                  ?>
                  <p class="card-title">ลูกทีม : <?php echo e($childname->name); ?></p>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>


    </div>





<?php $__env->stopSection(); ?>




<?php $__env->startSection('script'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\downline\resources\views/user/treeview.blade.php ENDPATH**/ ?>