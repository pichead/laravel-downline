<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('others/styles/Datatable.css')); ?>">




<style>

  .dataTables_length{
    display: none;
  }
  .dataTables_filter{
    display: none;
  }     

</style>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
    $level = Auth::user()->level_id ;
?>
<div class="container mb-5 col-lx-9">
    <div class="mx-auto col-12 p-0">
        <?php echo $__env->make('inc.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php if($level == 1): ?>
    <div class="form-row mx-0 my-auto">
        <div class="col-12 my-auto px-0 h3">รายการตัวแทน</div>
        <div class="col-12 col-md-6 col-lg-8 p-0 mt-3">
            <div class="col-12 pl-lg-0 px-0">
              <input type="text" id="search-bar" class="form-control search-input m-0" placeholder="Search..." />
            </div>
          </div>
          <div class="col-12 col-md-6 col-lg-4 mt-3 d-flex justify-content-center px-0">
            <a class="btn col ml-md-3 px-auto blue-btn" href="<?php echo e(asset('userSignup')); ?>" type="button">สร้างตัวแทน</a>
            <a class="btn col ml-3 px-auto hblue-btn" href="<?php echo e(asset('Treeview')); ?>" type="button">มุมมองเครือข่าย</a>
          </div>
    </div>
    <?php elseif($level == 2): ?>
    <div class="form-row mx-0 my-auto">
      <div class="col-12 my-auto px-0 h3">รายการลูกทีม</div>
      <div class="col-12 col-md-8 col-lg-10 p-0 mt-3">
        <div class="col-12 pl-lg-0 px-0">
          <input type="text" id="search-bar" class="form-control search-input m-0" placeholder="Search..." />
        </div>
      </div>
      <div class="col-12 col-md-4 col-lg-2 mt-3 d-flex justify-content-center px-0 ">
        <a class="btn col ml-md-3" href="<?php echo e(asset('userSignup')); ?>" type="button" style="background-color: #72CAFF;color:white">สร้างลูกทีม</a>
      </div>
    </div>
    <?php endif; ?>


    
    <div class=" mt-4">
        <table id="tb-stocks" class="re-table table-mobile table-stocks mt-2 mb-4">
          <thead>
            <tr>
                <th class="text-lg-center" scope="col">ลำดับ</th>
                <th class="text-lg-center" scope="col">ชื่อ-สกุล</th>
                <th class="text-lg-center" scope="col">เบอร์ติดต่อ</th>
                <th class="text-lg-center" scope="col">อีเมล</th>
                <th class="text-lg-center" scope="col"></th>
            </tr>
        </thead>

        <tbody>
            <?php
                $count = 0;
            ?>
            <?php $__currentLoopData = $UserTree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $User_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php
                    $childs = App\Models\User::where('id',$User_row->child_id)->get();                   
                ?>
                
                
                <?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                      $count = $count+1;
                  ?>
                <tr>
                    <td class="text-xl-center px-0"><div class="pl-2"><?php echo e($count); ?></div></td>
                    <td class="px-0"><div class="pl-2"><span class="stock-extra-unit"><?php echo e($loop->index+1); ?>. </span><?php echo e($child->name); ?></div></td>
                    <td class="text-xl-center px-0" ><div class="pl-2"><span class="stock-extra-unit">เบอร์ติดต่อ : </span>0<?php echo e($child->tel); ?></div></td>
                    <td class=" px-0"><div class="pl-2"><span class="stock-extra-unit">อีเมล : </span><?php echo e($child->email); ?></div></td>
                    <td class="d-flex justify-content-center px-0">
                        <a class="btn mr-2 green-btn btn-sm" type="button" href="<?php echo e(asset('price').'/'.$child->id); ?>">เรทราคา</a>
                        <form method="POST" action="<?php echo e(asset('ResetPassword')); ?>"  enctype="multipart/form-data">
                          <?php echo e(method_field('PUT')); ?>

                          <?php echo csrf_field(); ?>
                          <button class="btn red-btn btn-sm" type="submit" name="id" value="<?php echo e($child->id); ?>">รีเซ็ตรหัสผ่าน</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
        </tbody>
        </table>
    </div>


</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>



<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>


<script type="text/javascript">


  $(document).ready( function () {


  $('#modal-btn-yes').click(function(){
      deleteStock();
  });

  $('#tb-stocks').dataTable( {
      "ordering":false,
      "info":true,
      // "dom": '<"top"i>rt<"bottom"><"clear">'
  } );


  $('#search-bar').on( 'keyup click', function () {
        // table.search($('#mySearchText').val()).draw();
        $('#tb-stocks').dataTable().fnFilter(this.value);

  } );


} );

</script>


<script type="text/javascript">

  function confirmDelete(id){

    var name = $('#btn-delete-' + id).data('name');


    $('#modal-btn-yes').data('id',id);

    $('#modal-stock-name').html('"' + name + '"');

    $('#deleteModal').modal('show');
  }
  function deleteStock(){

        var id = $('#modal-btn-yes').data('id');
        var token = $("meta[name='csrf-token']").attr("content");

        console.log(id);


        $.ajax({
        type:     "delete",
        url:      "./api/stocks/"+id,
        data: {
              _token: token,
          },
        success:function(response){
          location.reload();
        },
        error: function (xhr, status, error) {
            console.log(xhr.responseText);
        }
        });


    }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cp572785/public_html/v-dealers.com/app_v/resources/views/user/index.blade.php ENDPATH**/ ?>