

<?php $__env->startSection('content'); ?>
<br>
<div class="container col-12 col-md-11 col-xl-8">
  <h3 class="mx-auto text-center">สร้างสินค้า</h3>
  <br>
  <div class="mx-auto col-7 border border-secondary" style="background-color: white">
    <form method="POST" action="<?php echo e(asset('CreateStocks')); ?>"  enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="my-5 mx-5">
        <div class="form-group">
          <div class="col-12 p-0">ชื่อสินค้า</div>
          <input class="col-12 p-0" name="name" type="text">
        </div>
        <div class="form-group">
          <div class="col-12 p-0">จำนวน</div>
          <input class="col-12 p-0" name="amount" type="number">
        </div>
        <div class="row m-0">
          <div class="form-group col p-0 mr-2">
            <div class="col-12 p-0">ราคาต้นทุน</div>
            <input class="col-12 p-0" name="received_price" type="text">
          </div>
          <div class="form-group col p-0 ml-2">
            <div class="col-12 p-0">ราคาขาย</div>
            <input class="col-12 p-0" name="spent_price" type="text">
          </div>
        </div>
        <div class="row m-0">
          <div class="form-group col p-0 mr-2">
            <div class="col-12 p-0">หน่วยรับ</div>
            <input class="col-12 p-0" name="received_unit" type="text">
          </div>
          <div class="form-group col p-0 ml-2">
            <div class="col-12 p-0">หน่วยขาย</div>
            <input class="col-12 p-0" name="spent_unit" type="text">
          </div>
        </div>
        <div class="row">
            <div class="mx-auto my-3">
                <button class="btn px-4" name="create" type="submit" style="background-color: #D7B0EF; color:white;" value="บันทึกข้อมูล">บันทึก</button>
                <a class="btn px-4" href="<?php echo e(asset('stock')); ?>" type="button" style="background-color: #FF8D8D; color:white;">ยกเลิก</a>
            </div>
        </div>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dl\mlm-laravel\resources\views/stock/create.blade.php ENDPATH**/ ?>