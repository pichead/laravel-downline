

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('others/chosen/chosen.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('others/styles/Datatable.css')); ?>">




<style>

  .dataTables_length{
    display: none;
  }
  .dataTables_filter{
    display: none;
  }

  .print-wrapper{
    display: none;
  }

  @media  print {

                /* body *{
                  visibility: hidden;
                  height: 0;
                } */
                .content-wrapper{
                  display: none;
                }
                .print-wrapper{
                  display: block;
                  height: auto;
                  margin-top: -60px;
                }
                .print-wrapper,.print-wrapper *{
                  visibility: visible;
                  height: auto;
                }
                .tb-print-stock-history{
                  width: auto;;
                  margin: auto;
                }
                @page  {
                  size: A4 landscape;
                  margin: 3mm 3mm;

                }

  }
</style>



<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
<div class="col-11 mx-auto">
<div class="content-wrapper">
  <div class="container  mb-5 col-12">
    <div class="mx-auto col-12 p-0">
      <?php echo $__env->make('inc.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="form-row mx-0 my-auto">
      <div class="col-12 my-auto px-0 h3">ประวัติการขาย</div>
      
      <div class="col-12 p-5 mt-4 mx-0 rounded" style="background-color: white">

        <form action="<?php echo e(asset('payment/find')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-wrapper myboxShadow">
                    <div class="form-row">
                            <div class="form-group col-xl col-md-6">
                                <label>สถานะ</label>
                                <select id="status" name="status" class="custom-select">
                                    <option value="0" <?php echo e(($request_status_id  == 0) ? 'selected':''); ?>>ดูทั้งหมด</option>
                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($status_row->id); ?>" <?php echo e(($request_status_id == $status_row->id) ? 'selected':''); ?>><?php echo e($status_row->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group col-xl col-md-6">
                                <label>ตัวแทน</label>
                                <select id="child" name="child_id" class="custom-select">
                                    <option value="0" <?php echo e(($childID == 0) ? 'selected':''); ?>>ดูทั้งหมด</option>
                                    <?php $__currentLoopData = $child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($child_row->id); ?>" <?php echo e(($childID == $child_row->id) ? 'selected':''); ?>><?php echo e($child_row->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                        <div class="form-group col-xl col-md-6">
                        <label for="inputEmail4">วันและเวลาที่เริ่ม</label>
                            <div class="input-group date" id="start_date" data-target-input="nearest">
                            <input  name="start_date" type="text" class="form-control datetimepicker-input" data-target="#start_date" data-minlength="10" data-error="กรุณากรอกวันที่โดยใช้ปฏิทิน"  />
                            <div class="input-group-append" data-target="#start_date" data-toggle="datetimepicker">
                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                            </div>
                        </div>
                        </div>
                        <div class="form-group col-xl col-md-6">
                        <label for="inputEmail4">วันและเวลาที่สิ้นสุด</label>
                        <div class="input-group date" id="end_date" data-target-input="nearest">
                            <input  name="end_date" type="text" class="form-control datetimepicker-input" data-target="#end_date" data-minlength="10" data-error="กรุณากรอกวันที่โดยใช้ปฏิทิน" />
                            <div class="input-group-append" data-target="#end_date" data-toggle="datetimepicker">
                                <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                            </div>
                        </div>
                        </div>
                    </div>

                    <div class="btn-create-wrapper text-center mt-4">
                        <button type="submit" id="create-user-btn" name="create" class="btn col-xl-1 col-md-3 col-4 blue-btn" >ค้นหา</button>
                        <button type="button" id="reset-user-btn" name="reset" class="btn col-xl-1 col-md-3 col-4 red-btn" onclick="location.href='<?php echo e(asset('SaleList')); ?>';" >รีเซ็ต</button>
                    </div>
                </div>

        </form>
      </div>
    

      <div class="form-row col-12 mx-0 mb-3">
        <div class="col-12 col-md-8 col-lg-10 p-0 mt-3">
            <div class="col-12 pl-lg-0 px-0">
            <input type="text" id="search-bar" class="form-control search-input m-0" placeholder="Search..." />
            </div>
        </div>

        <form method="POST" id="convert_form" class="col-12 col-md-4 col-lg-2 mt-3 d-flex justify-content-center px-0" action="<?php echo e(asset('excel/download')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="file_name" id="file_name" value="รายงานประวัติการขายสินค้าและบริการ" />
            <input type="hidden" name="file_content" id="file_content" />
            <button class="btn col ml-md-3  mr-2 mr-md-auto green-btn" type="button" id="btn_convert_form" onclick="downloadExcel()" name="button">Excel</button>
          
            <button class="btn col ml-md-3 purple-btn" href="#" type="button" onclick="printTable()">พิมพ์</button>
        </form> 

    </div>

      <div class="tb-search-wrapper col-12 px-0">
        <table id="tb-stocks" class="re-table table-mobile table-stocks mb-4">
          <thead>
              <tr>
                  <th class="text-lg-center sorting_disabled" scope="col">No.</th>
                  <th class="text-lg-center sorting_disabled" scope="col">เลขคำสั่งซื้อ</th>
                  <th class="text-lg-center sorting_disabled" scope="col">วันที่</th>
                  <th class="text-lg-center sorting_disabled" scope="col">ตัวแทน</th>
                  <th class="text-lg-center sorting_disabled" scope="col">ชื่อบัญชี</th>
                  
                  <th class="text-lg-right sorting_disabled" scope="col">ยอดสั่งซื้อ</th>
                  <th class="text-lg-center sorting_disabled" scope="col">สถานะ</th>
                  <th class="text-lg-center sorting_disabled" scope="col"></th>
              </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $PurchaseOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PurchaseOrder_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $user = App\Models\User::where('id',$PurchaseOrder_row->buyer_id)->first();
                $price = App\Models\Order::where('purchase_order_id',$PurchaseOrder_row->id)->sum('price');               
                $status = App\Models\PurchaseOrderStatus::where('id',$PurchaseOrder_row->status_id)->first();
                if(isset($PurchaseOrder_row->user_bank_id)){
                  $user_bank = App\Models\UserBank::where('id',$PurchaseOrder_row->user_bank_id)->first();
                  $bank_name =  App\Models\Bank::where('id',$user_bank->bank_id)->first();
                }
              ?>
              <tr>
                <td class="text-xl-center py-auto px-0"><div class="pl-2"><?php echo e($loop->index+1); ?></div></td>
                <td class="text-xl-left py-auto px-0">
                  <div class="pl-2"><span class="stock-extra-unit"><?php echo e($loop->index+1); ?>. </span><?php echo e(number_format($PurchaseOrder_row->purchase_no,0,",","-")); ?></div>
                </td>
                <td class="text-xl-left py-auto px-0"><div class="pl-2"><span class="stock-extra-unit">วันที่ : </span><?php echo e(DateTime::createFromFormat('Y-m-d H:i:s', $PurchaseOrder_row->created_at)->format('d/m/Y H:i:s')); ?></div></td>
                <td class="text-xl-left py-auto px-0"><div class="pl-2"><span class="stock-extra-unit">ตัวแทน : </span><?php echo e($user->name); ?></td>
                <td class="text-xl-center py-auto px-0">
                  <div class="pl-2">
                    <?php if(isset($PurchaseOrder_row->user_bank_id)): ?>
                    <span class="stock-extra-unit">ชื่อบัญชี : </span><?php echo e($user_bank->name); ?>

                    <?php else: ?>
                      ยังไม่ได้ใส่ธนาคาร
                    
                    <?php endif; ?>
                  </div>
                </td>

                <td class="text-xl-right py-auto px-0"><div class="pl-2"><span class="stock-extra-unit">ราคา : </span><?php echo e(number_format($price,2)); ?></div>
                </td>
                <td class="text-xl-center py-auto px-0"><div class="pl-2"><span class="stock-extra-unit">สถานะ : </span><?php echo e($status->name); ?></div></td>
                <td class="text-center px-0">
                  <a class="btn blue-btn py-auto btn-sm" href="<?php echo e(asset('paymentdetail'.'/'.$PurchaseOrder_row->id)); ?>" >รายละเอียด</a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

      </div>
    </div>
  </div>
</div>

<div class="print-wrapper">

  <h4 class="text-center">V Dealers</h4>
  <h4 class="text-center">รายงานประวัติการขายสินค้าและบริการ</h4>
  <h5 class="text-center"><?php echo e($start_date); ?> - <?php echo e($end_date); ?></h5>

  <div class="mx-4 mt-5" style="font-size: 12px">
      <table class="table table-borderless">
      <thead class="border-top border-bottom border-dark">
        <th class="text-center" scope="col">No.</th>
                  <th class="text-center" scope="col">เลขคำสั่งซื้อ</th>
                  <th class="text-center" scope="col">วันที่</th>
                  <th class="text-center" scope="col">ตัวแทน</th>
                  <th class="text-center" scope="col">ชื่อบัญชี</th>
                  
                  <th class="text-right" scope="col">ยอดสั่งซื้อ</th>
                  <th class="text-center" scope="col">สถานะ</th>
      </thead>
      <tbody class="border-bottom border-dark">
        <?php if($PurchaseOrder->count() == 0): ?>
        <tr>
          <td colspan="10" class="text-center">
              ไม่มีรายการ
          </td>
        </tr>
        <?php endif; ?>
        <?php $__currentLoopData = $PurchaseOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PurchaseOrder_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $user = App\Models\User::where('id',$PurchaseOrder_row->buyer_id)->first();
                $price = App\Models\Order::where('purchase_order_id',$PurchaseOrder_row->id)->sum('price');               
                $status = App\Models\PurchaseOrderStatus::where('id',$PurchaseOrder_row->status_id)->first();
                if(isset($PurchaseOrder_row->user_bank_id)){
                  $user_bank = App\Models\UserBank::where('id',$PurchaseOrder_row->user_bank_id)->first();
                  $bank_name =  App\Models\Bank::where('id',$user_bank->bank_id)->first();
                }
              ?>
              <tr>
                <td class="text-center py-auto px-0"><div class="pl-2"><?php echo e($loop->index+1); ?></div></td>
                <td class="text-left py-auto px-0">
                  <div class="pl-2"><span class="stock-extra-unit"><?php echo e($loop->index+1); ?>. </span><?php echo e(number_format($PurchaseOrder_row->purchase_no,0,",","-")); ?></div>
                </td>
                <td class="text-left py-auto px-0"><div class="pl-2"><span class="stock-extra-unit">วันที่ : </span><?php echo e(DateTime::createFromFormat('Y-m-d H:i:s', $PurchaseOrder_row->created_at)->format('d/m/Y H:i:s')); ?></div></td>
                <td class="text-left py-auto px-0"><div class="pl-2"><span class="stock-extra-unit">ตัวแทน : </span><?php echo e($user->name); ?></td>
                <td class="text-center py-auto px-0">
                  <div class="pl-2">
                    <?php if(isset($PurchaseOrder_row->user_bank_id)): ?>
                    <span class="stock-extra-unit">ชื่อบัญชี : </span><?php echo e($user_bank->name); ?>

                    <?php else: ?>
                      ยังไม่ได้ใส่ธนาคาร
                    
                    <?php endif; ?>
                  </div>
                </td>
                
                <td class="text-right py-auto px-0"><div class="pl-2"><span class="stock-extra-unit">ราคา : </span><?php echo e(number_format($price,2)); ?></div>
                </td>
                <td class="text-center py-auto px-0"><div class="pl-2"><span class="stock-extra-unit">สถานะ : </span><?php echo e($status->name); ?></div></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>

<div id="excel_table" class="d-none">
  <table>
    <tr>
        <td colspan="7" class="text-center">รายงานยอดขายสินค้าและบริการ</td>
      </tr>
      <tr>
        <td colspan="7" class="text-center">V Dealers</td>
      </tr>
      <tr>
        <td colspan="7" class="text-center"><?php echo e($start_date); ?> - <?php echo e($end_date); ?></td>
      </tr>
      <?php if($request_status_id  == 0): ?>
        <tr>
          <td colspan="7" class="text-center">สถานะ : ทั้งหมด</td>
        </tr>
      <?php else: ?>
        <?php
          $stock = App\Models\PurchaseOrderStatus::where('id',$request_status_id)->first();
        ?>
        <tr>
          <td colspan="7" class="text-center">สถานะ : <?php echo e($status->name); ?></td>
        </tr>
      <?php endif; ?>
      <?php if($childID == 0): ?>
        <tr>
          <td colspan="7" class="text-center">ตัวแทน/ลูกทีม : ทั้งหมด</td>
        </tr>
      <?php else: ?>
        <?php
          $user= App\Models\User::where('id',$childID)->first();
        ?>
        <tr>
          <td colspan="7" class="text-center">ตัวแทน/ลูกทีม : <?php echo e($user->name); ?></td>
        </tr>
      <?php endif; ?>
    <thead>
        <tr>
            <th>No.</th>
            <th>เลขคำสั่งซื้อ</th>
            <th>วันที่</th>
            <th>ตัวแทน</th>
            <th>ชื่อบัญชี</th>
            <th>ยอดสั่งซื้อ</th>
            <th>สถานะ</th>
        </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $PurchaseOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $PurchaseOrder_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $user = App\Models\User::where('id',$PurchaseOrder_row->buyer_id)->first();
          $price = App\Models\Order::where('purchase_order_id',$PurchaseOrder_row->id)->sum('price');               
          $status = App\Models\PurchaseOrderStatus::where('id',$PurchaseOrder_row->status_id)->first();
          if(isset($PurchaseOrder_row->user_bank_id)){
            $user_bank = App\Models\UserBank::where('id',$PurchaseOrder_row->user_bank_id)->first();
            $bank_name =  App\Models\Bank::where('id',$user_bank->bank_id)->first();
          }
        ?>
        <tr>
          <td><?php echo e($loop->index+1); ?></td>
          <td><?php echo e(number_format($PurchaseOrder_row->purchase_no,0,",","-")); ?></td>
          <td><?php echo e(DateTime::createFromFormat('Y-m-d H:i:s', $PurchaseOrder_row->created_at)->format('d/m/Y H:i:s')); ?></td>
          <td><?php echo e($user->name); ?></td>
          <td>
              <?php if(isset($PurchaseOrder_row->user_bank_id)): ?>
                <?php echo e($user_bank->name); ?>

              <?php else: ?>
                ยังไม่ได้ใส่ธนาคาร
              <?php endif; ?>

          </td>

          <td><?php echo e($price); ?></td>
          <td><?php echo e($status->name); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>


</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo e(asset('others/bootstrap-validator/validator.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('others/moment/moment-with-locales.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('others/datetime-picker/tempusdominus.js')); ?>"></script>
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tempusdominus-bootstrap-4/5.0.1/css/tempusdominus-bootstrap-4.min.css" /> -->
<link rel="stylesheet" href="<?php echo e(asset('others/datetime-picker/datetime-picker.css')); ?>" />

<!--  chosen -->

<script type="text/javascript" src="<?php echo e(asset('others/chosen/chosen.jquery.js')); ?>"></script>

<script type="text/javascript">




  $("#child").chosen({
    no_results_text: "no results",
    // search_contains: true,
    // allow_duplicates:true,
    width:'100%',
    
  });
  
  
  
  $("#status").chosen({
    no_results_text: "no results",
    search_contains: true,
    // allow_duplicates:true,
    width:'100%',
  });
  
  </script>

<script type="text/javascript">


  $(document).ready( function () {


  $('#modal-btn-yes').click(function(){
      deleteStock();
  });

  $('#tb-stocks').dataTable( {
      "ordering":false,
      "info":true,
      // "dom": '<"top"i>rt<"bottom"><"clear">'
  } );


  $('#search-bar').on( 'keyup click', function () {
        // table.search($('#mySearchText').val()).draw();
        $('#tb-stocks').dataTable().fnFilter(this.value);

  } );


} );

</script>
<script type="text/javascript">

  function downloadExcel(){

  var url ="../api/excel/download";

  var html_table = $("#excel_table").html();
  
  $('#file_content').val(html_table);
  console.log(html_table)

  $('#convert_form').submit();
  

  }
</script>


<script type="text/javascript">


function printTable(){

  window.print();
}





$(function () {
    $('#start_date').datetimepicker({
      // format: 'd/m/Y H:i',
      locale: 'th',
      defaultDate: moment('<?php echo e($start_date); ?>')
    });
});

$(function () {
    $('#end_date').datetimepicker({
      // format: 'd/m/Y H:i',
      locale: 'th',
      defaultDate: moment('<?php echo e($end_date); ?>')
    });
});


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\downline\resources\views/payment/indexseller.blade.php ENDPATH**/ ?>