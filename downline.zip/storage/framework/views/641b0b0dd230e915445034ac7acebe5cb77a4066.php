<?php $__env->startSection('content'); ?>
<br>
<div class="container mb-5">
    <div class="row clearfix">
        <h3 class="mx-auto">แก้ไขข้อมูลส่วนตัว</h3>
    </div>
    <br>
<form method="POST" action="<?php echo e(asset(('EditUser').('/').(Auth::user()->id))); ?>" oninput='cm_password.setCustomValidity(cm_password.value != password.value ? "รหัสผ่านไม่ตรงกัน" : "")' enctype="multipart/form-data">

    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-11 col-md-8 col-lg-6 border border-dark mx-auto p-5 rounded" style="background-color: white;">
            <div class="mx-2" data-toggle="validator" role="form">
                <?php $__currentLoopData = $user_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                        <label>ชื่อ-สกุล</label>
                        <input name="name" class="form-control" type="name" value="<?php echo e($user->name); ?>"> 
                    </div>
                    <div class="form-group">
                        <label>เบอร์ติดต่อ</label>
                        <input name="tel" class="form-control" type="tel" value="0<?php echo e($user->tel); ?>"> 
                    </div>
                    <div class="form-group">
                        <label>E-mail</label>
                        <input name="email" class="form-control" type="email" value="<?php echo e($user->email); ?>"> 
                    </div>
                    <div class="form-group">
                        <label>ธนาคาร</label>
                    </div>
                    <div class="form-group">
                        <?php
                          $bank = App\Models\UserBank::where('user_id',$user->id)->get();
                        ?>
                        <?php $__currentLoopData = $bank; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $bank = App\Models\Bank::where('id',($bank_row->bank_id))->first();
                        ?>
                        <input readonly="readonly" class="form-control" value="<?php echo e($bank->name); ?>"/>
                        <input readonly="readonly" class="mt-2 form-control" value="<?php echo e($bank_row->account_no); ?>"/>
                        <br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <a class="btn col-12 green-btn" href="<?php echo e(asset('UserBank'."/".$user->id)); ?>" type="button" id="AddBank">จัดการธนาคาร</a>
                    </div>

                    <div class="row mt-5">
                        <div class="mx-auto">
                            <button id="sm-tbn" class="btn px-4 purple-btn" name="create" type="submit" value="บันทึกข้อมูล" >บันทึก</button>
                            <button class="btn px-4 red-btn" href="<?php echo e(asset('userList')); ?>" type="button" >ยกเลิก</button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</form>

<script type="text/javascript" src="<?php echo e(asset('bootstrap/validator.js')); ?>"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cp572785/public_html/v-dealers.com/app_v/resources/views/user/edit.blade.php ENDPATH**/ ?>