<div id="json-response-modal" class="alert alert-success alert-dismissible fade">
    <span id="json-response-message"></span>
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
    </div><?php /**PATH C:\xampp\htdocs\downline\resources\views/inc/mymodal.blade.php ENDPATH**/ ?>