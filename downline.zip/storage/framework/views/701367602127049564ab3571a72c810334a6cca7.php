<?php $__env->startSection('content'); ?>

<div id="app">
    <user-component></user-component>
</div>






<script src="js/app.js" charset="utf-8"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dl\mlm-laravel\resources\views/user/test.blade.php ENDPATH**/ ?>