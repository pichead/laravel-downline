<?php $__env->startSection('content'); ?>
<br>
<div class="container mb-5">
    <div class="row clearfix">
        <h3 class="mx-auto">ชำระเงิน</h3>
    </div>
    <br>
    

        <?php 
            $buyer = App\Models\User::where('id',$Payment->buyer_id)->first()
        ?>

        <div class="row">
            <div class="col-11 col-md-8 border border-dark mx-auto p-5 rounded" style="background-color: white;">
                <div class="row">
                    <div class="col-12  mx-auto " style="background-color: white;">
                        <div class="mx-2">
                            <div class="form-row">
                                <div class="col my-auto p-0">วันที่สั่งซื้อ : <?php echo e($Payment->created_at); ?></div>
                                <div class="col clearfix p-0">
                                    <button class="btn float-right green-btn" data-toggle="modal" data-target="#status" type="button">อัพเดตสถานะ</button>
                                </div>
                                <div class="modal" id="status">
                                    <div class="modal-dialog">
                                        <form method="POST" action="<?php echo e(asset('PaymentStatusUpdate').'/'.$Payment->id); ?>"  enctype="multipart/form-data">
                                            <?php echo e(method_field('PUT')); ?>

                                            <?php echo csrf_field(); ?>
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                <h5 class="modal-title">สถานะการสั่งซื้อ</h5>
                                                <button class="close " data-dismiss="modal">×</button>
                                                </div>
                                                <div class="modal-body m-3">
                                                    <div class="form-row">
                                                        <?php
                                                            $status = App\Models\PurchaseOrderStatus::where('id',$Payment->status_id)->first();         
                                                        ?>
                                                        <select class="custom-select my-3" id="inlineFormCustomSelect"  name="status">
                                                            <option hidden value="<?php echo e($status->id); ?>"><?php echo e($status->name); ?></option>
                                                            <option value="2">ยินยันแล้ว</option>
                                                            <option value="1">รอการยืนยัน</option>
                                                            <option value="3">ยกเลิก</option>
                                                            <option value="4">คืนเงิน</option>
                                                        </select>
                                                        
                                                    </div>
                                                    <div class="form-row">
                                                        <textarea class="form-control" id="message" rows="3" name="seller_comment"><?php echo e($Payment->seller_comment); ?></textarea>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit"  class="btn green-btn">บันทึก</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                  </div>
                            </div>
                            <br>
                            <div class="form-group">
                                <label>เลขที่สั่งซื้อสินค้า</label>
                                <input class="form-control" type="number" value="<?php echo e($Payment->purchase_no); ?>" readonly>
                            </div>

                            <table id="tb-stocks" class="col-12 table-mobile table-stocks mt-2 mb-4">
                                <thead>
                                    <tr class="row m-0 table-success py-1">
                                        <td class="col-12 col-xl-1  text-lg-center sorting_disabled" >No.</td>
                                        <td class="col-12 col-xl text-lg-center sorting_disabled" >รายการสินค้า</td>
                                        <td class="col-12 col-xl text-lg-center sorting_disabled" >จำนวน</td>
                                        <td class="col-12 col-xl text-lg-center sorting_disabled">ราคา</td>
                                    </tr>
                                </thead>
                        
                                <tbody>
                                  <?php $__currentLoopData = $Order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Order_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $name = App\Models\Stock::where('id',$Order_row->stock_id)->first();                   
                                    ?>
                                    <tr role="row" class="row m-0 py-1">
                                      <td class="col-12 col-xl-1 text-lg-center"><?php echo e($loop->index+1); ?></td>
                                      <td class="col-12 col-xl ">
                                          <span class="stock-extra-unit"><?php echo e($loop->index+1); ?>. </span><?php echo e($name->name); ?>

                                      </td>
                                      <td class="col-12 col-xl text-lg-right"><?php echo e(number_format($Order_row->amount,0)); ?></td>
                                      
                                        <?php $__currentLoopData = $priceitem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($Order_row->amount >= $price_row->start_total && $Order_row->amount <= $price_row->end_total && $price_row->stock_id == $Order_row->stock_id): ?>
                                                <?php
                                                    $amount = $Order_row->amount;
                                                    $priceperunit = $price_row->price;
                                                    $total = $amount * $priceperunit;

                                                ?>
                                                
                                                <td class="col-12 col-xl text-lg-right"><?php echo e(number_format($total,2)); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      
                                    </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <td class="col-12 mt-2 text-right font-weight-bold">ยอดสั่งซื้อ(บาท) <?php echo e(number_format($Price,2)); ?></td>
                                </tfoot>
                              </table>

                            <div class="form-group">
                                <label>ชื่อผู้ซื้อ</label>
                                <input class="form-control" type="fullname" value="<?php echo e($buyer->name); ?>" readonly/>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>เบอร์ติดต่อ</label>
                                    <input type="tel" class="form-control" value="0<?php echo e($buyer->tel); ?>" readonly/>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>E-mail</label>
                                    <input type="email" class="form-control" value="<?php echo e($buyer->email); ?>" readonly/>
                                </div>
                            </div>                    
                            <div class="form-group">
                                <label>โอนไปที่ธนาคาร</label>
                                <?php
                                if(isset($Payment->user_bank_id)){
                                    $bank_acc = App\Models\UserBank::where('id',$Payment->user_bank_id)->first();
                                    $bank = App\Models\Bank::where('id',$bank_acc->bank_id)->first();
                                }
                                ?>
                                <?php if(isset ($bank->name)): ?>
                                <input readonly="readonly" class="form-control" value="<?php echo e($bank->name); ?>"/>
                                <?php else: ?>
                                <input readonly="readonly" class="form-control" value="-"/>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <label>เลขบัญชีธนาคาร</label>
                                <?php if(isset ($bank_acc->account_no)): ?>
                                <input readonly="readonly" class="form-control" value="<?php echo e($bank_acc->account_no); ?>"/>
                                <?php else: ?>
                                <input readonly="readonly" class="form-control" value="-"/>
                                <?php endif; ?>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>วันที่ชำระเงิน</label>
                                    <?php if(isset($Payment->pay_date)): ?>
                                    <input readonly="readonly" class="form-control" value="<?php echo e($Payment->pay_date->format('d/m/Y')); ?>"/>
                                    <?php else: ?>
                                    <input readonly="readonly" class="form-control"  value="-"/>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>เวลา</label>
                                    <?php if(isset($Payment->pay_time)): ?>
                                    <input readonly="readonly" class="form-control" type="time" value="<?php echo e($Payment->pay_time->format('H:i')); ?>"/>
                                    <?php else: ?>
                                    <input readonly="readonly" class="form-control" value="-"/>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label>ยอดสั่งซื้อ</label>
                                    <?php
                                    $price = App\Models\Order::where('purchase_order_id',$Payment->id)->sum('price');
                                    ?>
                                    <input class="form-control" value="<?php echo e(number_format($price,2)); ?>" readonly/>
                                </div>
                                <div class="form-group col-md-6">
                                    <label>ยอดโอน</label>
                                    <?php if(isset($Payment->pay_price)): ?>
                                    <input class="form-control" name="pay_price" value="<?php echo e(number_format($Payment->pay_price,2)); ?>" readonly/>
                                    <?php else: ?>
                                    <input class="form-control" name="pay_price" value="-" readonly/>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <label>ไฟล์แนบ</label>
                                <?php $__currentLoopData = $file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="">
                                        <a target="_new" href="<?php echo e(asset('app_v/public/uploads').'/'.$file_row->name.'/'); ?>"><?php echo e($loop->index+1); ?>. <?php echo e($file_row->name); ?></a>
                                    </div>
                                    <br>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php if( $Payment->buyer_comment != []): ?>
                            <div class="form-row">
                                <label for="message">เพิ่มเติม</label>
                                <input class="form-control"  value="<?php echo e($Payment->buyer_comment); ?>" readonly/>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

    
        <br>
        <br>

</div>

<?php $__env->stopSection(); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(function(){
    $("#bank").change(function(){
        var no=$("#bank option:selected").data("no");
        console.log(no);
        $("#no").val(no);
    })
})

// $(function(){
//     $("#addprice").click(function(){
//         $(".btnaddrow").before('<tr role="row" class="price row m-0 mb-5 mb-xl-0"><td class="col col-xl text-lg-center"><div class="row "><input class="col-3 mx-auto">-<input class="col-3 mx-auto"></div></td><td class="col col-xl text-lg-center"><input class="col-4"></td><td class="col-1 col-xl-1 text-lg-center"><div class="delrow">X</div></td></tr>');
//     })
// })
</script>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cp572785/public_html/v-dealers.com/app_v/resources/views/payment/detail.blade.php ENDPATH**/ ?>