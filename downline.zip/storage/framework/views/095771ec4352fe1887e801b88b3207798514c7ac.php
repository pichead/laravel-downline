<nav class="navbar fixed-top navbar-dark navbar-expand-sm p-0" style="background-color:#666a77;">
    <div class="container px-0 mx-0 mx-lg-5 px-lg-5 col-12 pr-lg-5">
        <img src="<?php echo e(URL::to('others/favicon/vdealer-logo-sq300.png')); ?>" width="65" height="65">
        <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse " id="navbarNav" >
            <ul class="navbar-nav ml-0 ml-sm-auto" >
                <?php
                    $user = Auth::user()->id;
                    $itemss = App\Models\Cart::where("user_id",$user)->get();
                    $price = App\Models\Price::where('user_id',$user)->get();

                    foreach($itemss as $item_row){
                        $price_item = App\Models\Price::where('user_id',$user)->where('stock_id',$item_row->stock_id)->get();
                        $array_price = [];
                        foreach($price_item as $price_item_row){
                            if($item_row->amount >= $price_item_row->start_total && $item_row->amount <= $price_item_row->end_total){
                                array_push($array_price,$price_item_row->price); 
                            }
                        }
                        if($array_price == []){
                            $del_item = App\Models\Cart::where('id',$item_row->id)->first();
                            $del_item->delete();
                        }
                    }
                    $level = Auth::user()->level_id ;
                    $cart_count = App\Models\Cart::where('user_id',Auth::user()->id)->count();
                ?>
                
                <?php if($level == 3): ?>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('stock') ? 'border-bottom-white' : ''); ?>">
                    <a class="nav-link navFont py-4 " href="<?php echo e(asset('stock')); ?>">รายการสินค้า</a>
                </li>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('BuyList') ? 'border-bottom-white' : ''); ?>">
                    <a class="nav-link navFont py-4 " href="<?php echo e(asset('BuyList')); ?>">ประวัติการสั่งซื้อ</a>
                </li>


                
                <?php elseif($level == 2): ?>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('stock') ? 'border-bottom-white' : ''); ?>">
                    <a class="nav-link navFont py-4 " href="<?php echo e(asset('stock')); ?>">รายการสินค้า</a>
                </li>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('BuyList') ? 'border-bottom-white' : ''); ?>">
                    <a class="nav-link navFont py-4 " href="<?php echo e(asset('BuyList')); ?>">ประวัติการสั่งซื้อ</a>
                </li>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('SaleList') ? 'border-bottom-white' : ''); ?>">
                    <a class="nav-link navFont py-4 " href="<?php echo e(asset('SaleList')); ?>">ประวัติการขาย</a>
                </li>



                
                <?php else: ?>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('stock') ? 'border-bottom-white' : ''); ?>" style="border-bottom: 5px;" >
                    <a class="nav-link navFont py-4 "  href="<?php echo e(asset('stock')); ?>" >คลังสินค้า</a>
                </li>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('SaleList') ? 'border-bottom-white' : ''); ?>">
                    <a class="nav-link navFont py-4 " href="<?php echo e(asset('SaleList')); ?>">ประวัติการขาย</a>
                </li>
                <?php endif; ?>
                
                
                
                
                <?php if($level == 3): ?>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('cart') ? 'border-bottom-white' : ''); ?>">
                    <a class="nav-link navFont py-4 "  href="<?php echo e(asset('cart')); ?>"><i class="p-0 fas fa-shopping-cart"></i><span class="align-text-top badge badge-pill badge-danger"><?php echo e($cart_count); ?></span>
                    </a>
                </li>
                <?php elseif(($level == 1)): ?>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('SaleReport') ? 'border-bottom-white' : ''); ?>">
                    <a class="nav-link navFont py-4 " href="<?php echo e(asset('SaleReport')); ?>">รายงานยอดขาย</a>
                </li>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('userList') ? 'border-bottom-white' : ''); ?>">
                    <a class="nav-link navFont py-4 " href="<?php echo e(asset('userList')); ?>">ตัวแทน</a>
                </li>
                <?php elseif(($level == 2)): ?>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('SaleReport') ? 'border-bottom-white' : ''); ?>">
                    <a class="nav-link navFont py-4 " href="<?php echo e(asset('SaleReport')); ?>">รายงานยอดขาย</a>
                </li>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('userList') ? 'border-bottom-white' : ''); ?>">
                    <a class="nav-link navFont py-4 " href="<?php echo e(asset('userList')); ?>">ลูกทีม</a>
                </li>
                <li style="height: 65px;" class="nav-item mx-1 my-auto <?php echo e(Request::is('cart') ? 'border-bottom-white' : ''); ?>">
                    <a class="nav-link navFont py-4 " href="<?php echo e(asset('cart')); ?>"><i class="p-0 fas fa-shopping-cart"></i><span class="align-text-top badge badge-pill badge-danger"><?php echo e($cart_count); ?></span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                </li>
                <?php if(Route::has('register')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                </li>
                <?php endif; ?>
                <?php else: ?>
                <li style="height: 65px;" class="nav-item dropdown my-auto">
                    <?php 
                        $level_name = App\Models\UserLevel::where("id",$level)->first();
                    ?>
                    <a id="navbarDropdown" class="nav-link dropdown-toggle  py-4" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?>

                    </a>

                    <div class="dropdown-menu dropdown-menu-right " aria-labelledby="navbarDropdown">
                        <a class="dropdown-item " href="<?php echo e(asset('EditUser')); ?>">ข้อมูลส่วนตัว (<?php echo e($level_name->name); ?>)</a>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <?php echo e(__('ออกจากระบบ')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
                <?php endif; ?>
            </ul>



        </div>
    </div>
</nav>
<br>
<br>
<br>
<br><?php /**PATH C:\xampp\htdocs\downline\resources\views/inc/navbar.blade.php ENDPATH**/ ?>