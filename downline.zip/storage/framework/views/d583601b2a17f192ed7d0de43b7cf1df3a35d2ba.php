

<?php $__env->startSection('content'); ?>
<br>
<div class="container mb-5">    
    <div class="col-10 mx-auto">
        <h3>สรุปรายการสินค้า</h3>
        <br>
    
        <?php $__currentLoopData = $price; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($price_row); ?>

            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
        <br>
        <div class="border border-secondary" style="background-color: white">
        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mx-3 p-2"> 
            <?php
                $name = App\Models\Stock::where('id',$item_row->stock_id)->get();                   
            ?>
            <div class="col-4 my-auto"><?php echo e($loop->index+1); ?>.
            <?php $__currentLoopData = $name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($name_row->name); ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="col-2 my-auto row mx-0">
            <div class="col-6 px-0">จำนวน</div>
            <div class="border px-0 border-secondary col-6 text-center"><?php echo e($item_row->amount); ?></div>
            </div>
            <div class="col-4 my-auto text-center">ราคา 2000 บาท</div>
            <button class="col-2  btn btn-danger" type="button"> Remove</button>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <div class="py-2 clearfix" style="background-color: aqua">
            <div class="col-12 p-0 float-right">ราคารวมทั้งหมด 8000 บาท</div>
        </div>
        </div>
        <div>*** กรุณาชำระเงินไปที่ เลขบัญชี 557-87557-74 ธนาคารกสิกรไทย นางสาวกชกช โขอออนัน</div>
        <div class="row">
            <div class="mx-auto">
                <button class="btn px-4" type="button" style="background-color: #D7B0EF; color:white;">บันทึก</button>
                <button class="btn px-4" type="button" style="background-color: #FF8D8D; color:white;">ยกเลิก</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dl\mlm-laravel\resources\views/payment/cart.blade.php ENDPATH**/ ?>