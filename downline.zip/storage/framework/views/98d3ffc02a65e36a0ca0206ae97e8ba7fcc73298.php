<?php $__env->startSection('content'); ?>
<br>
<div class="container col-11 col-md-11 col-xl-10">
    <div class="row">
      <div class="col-md-4 h3 pl-0">รายการโอน</div>
    </div>
    <br>
    <?php $__currentLoopData = $Payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Payment_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row mb-3" data-toggle="modal" data-target="#<?php echo e($Payment_row->id); ?>">
      <div class="col-12 mx-auto">
        <div class="row py-3 border border-secondary" style="background-color:white;">
          <div class="col-12 col-md-2 my-md-auto my-1">
            Payment ID: <?php echo e($Payment_row->purchase_no); ?>

          </div>
          <div class="col-12 col-md my-md-auto my-1">
            <span class="d-md-none">วันที่ : </span><?php echo e(DateTime::createFromFormat('Y-m-d H:i:s', $Payment_row->created_at)->format('d/m/Y H:i:s')); ?> 
          </div>
          <?php
              $price = App\Models\Order::where('purchase_order_id',$Payment_row->id)->sum('price');                   
          ?>
          <div class="col-12 col-md my-md-auto my-1">
            รวมทั้งหมด <?php echo e(number_format($price,2)); ?> บาท
          </div>
          <?php
              $status = App\Models\PurchaseOrderStatus::where('id',$Payment_row->status_id)->first();         
          ?>
          <div class="col-12 col-md-2 my-md-auto my-1">
            สถานะ : <?php echo e($status->name); ?>

          </div>
          <div class="col-5 col-md-2 my-md-auto my-1">
            <a class="btn col-12" href="<?php echo e(asset('paymentdetail'.'/'.$Payment_row->id)); ?>" style="background-color: #72CAFF;color:white">รายละเอียด</a>
          </div>
          <div class="col-5 col-md-2 my-md-auto my-1">
             <a class="btn col-12" href="<?php echo e(asset('payment'.'/'.$Payment_row->id)); ?>" style="background-color: #72CAFF;color:white">แจ้งโอน</a>
          </div>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $Payment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Payment_row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form method="POST" action="<?php echo e(asset('PaymentStatusUpdate').'/'.$Payment_row->id); ?>"  enctype="multipart/form-data">
      <?php echo e(method_field('PUT')); ?>

      <?php echo csrf_field(); ?>
      <div class="modal fade" id="<?php echo e($Payment_row->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
          <div class="modal-content p-2">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Payment ID: <?php echo e($Payment_row->purchase_no); ?></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
              <br>

            </div>
            <div class="modal-body">
              <div class="">วันที่สั่งซื้อ : <?php echo e($Payment_row->created_at); ?></div>
              <br>
              <div class="row">
                <div class="col-12  mx-auto " style="background-color: white;">
                    <div class="mx-2">
                        <div class="form-group">
                            <label>เลขที่สั่งซื้อสินค้า</label>
                            <input class="form-control" type="number" value="<?php echo e($Payment_row->purchase_no); ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label>ชื่อผู้ซื้อ</label>
                            
                              <?php 
                                $name = App\Models\User::where('id',$Payment_row->buyer_id)->first()
                              ?>

                              <input class="form-control" type="fullname" value="<?php echo e($name->name); ?>" readonly/>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>เบอร์ติดต่อ</label>
                                <input type="tel" class="form-control" value="0<?php echo e($name->tel); ?>" readonly/>
                            </div>
                            <div class="form-group col-md-6">
                                <label>E-mail</label>
                                <input type="email" class="form-control" value="<?php echo e($name->email); ?>" readonly/>
                            </div>
                        </div>                    
                        <div class="form-group">
                            <label>โอนไปที่ธนาคาร</label>
                            <?php
                              $bank = App\Models\Bank::where('id',$Payment_row->user_bank_id)->first();
                              $bank_acc = App\Models\UserBank::where('user_id',$Payment_row->seller_id)->where('bank_id',$Payment_row->user_bank_id)->first();
                            ?>
                            <?php if(isset ($bank->name)): ?>
                            <input readonly="readonly" class="form-control" value="<?php echo e($bank->name); ?>"/>
                            <?php else: ?>
                            <input readonly="readonly" class="form-control" value="-"/>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label>เลขบัญชีธนาคาร</label>
                            <?php if(isset ($bank_acc->account_no)): ?>
                            <input readonly="readonly" class="form-control" value="<?php echo e($bank_acc->account_no); ?>"/>
                            <?php else: ?>
                            <input readonly="readonly" class="form-control" value="-"/>
                            <?php endif; ?>
                          </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>วันที่ชำระเงิน</label>
                                <?php if(isset($Payment_row->pay_date)): ?>
                                <input readonly="readonly" class="form-control" value="<?php echo e($Payment_row->pay_date->format('d/m/Y')); ?>"/>
                                <?php else: ?>
                                <input readonly="readonly" class="form-control"  value="-"/>
                                <?php endif; ?>
                              </div>
                            <div class="form-group col-md-6">
                                <label>เวลา</label>
                                <?php if(isset($Payment_row->pay_time)): ?>
                                <input readonly="readonly" class="form-control" type="time" value="<?php echo e($Payment_row->pay_time->format('H:i')); ?>"/>
                                <?php else: ?>
                                <input readonly="readonly" class="form-control" value="-"/>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>ราคาสินค้า</label>
                                <?php
                                  $price = App\Models\Order::where('purchase_order_id',$Payment_row->id)->sum('price');
                                ?>
                                <input class="form-control" value="<?php echo e(number_format($price,2)); ?>" readonly/>
                            </div>
                            <div class="form-group col-md-6">
                                <label>จำนวนเงินที่โอน</label>
                                <?php if(isset($Payment_row->pay_price)): ?>
                                <input class="form-control" name="pay_price" value="<?php echo e(number_format($Payment_row->pay_price,2)); ?>" readonly/>
                                <?php else: ?>
                                <input class="form-control" name="pay_price" value="-" readonly/>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-row">
                          <?php
                            $status = App\Models\PurchaseOrderStatus::where('id',$Payment_row->status_id)->first();         
                          ?>
                          <select class="custom-select mr-sm-2 " id="inlineFormCustomSelect"  name="status">
                            <option hidden><?php echo e($status->name); ?></option>
                            <option value="2">ยินยันแล้ว</option>
                            <option value="1">รอการยืนยัน</option>
                            <option value="3">ยกเลิก</option>
                          </select>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">กลับ</button>
              <button type="submit" class="btn btn-primary">อัพเดต</button>
            </div>
          </div>
        </div>
      </div>
    </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\downline\resources\views/payment/index.blade.php ENDPATH**/ ?>